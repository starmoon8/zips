---
name: Bug report
about: Create a report to help us improve
title: ''
labels: bug
assignees: ''
---

**Describe the bug**
A clear and concise description of what the bug is.

**To Reproduce**
Steps to reproduce the behavior:
1. Run command '...'
2. Enter '...'
3. See error

**Expected behavior**
A clear and concise description of what you expected to happen.

**Error output**
```
Paste any error messages here
```

**Environment:**
- OS: [e.g. macOS 14.0, Ubuntu 22.04, Windows 11]
- Lockbox version: [e.g. 0.1.0]
- Installation method: [e.g. cargo install, pre-built binary, from source]

**Additional context**
Add any other context about the problem here.
